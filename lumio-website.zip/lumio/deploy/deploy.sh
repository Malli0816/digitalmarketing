#!/usr/bin/env bash
# Run on the Azure Linux VM (Ubuntu/Debian) from the folder that contains site/ and deploy/
#   chmod +x deploy/deploy.sh && sudo ./deploy/deploy.sh
set -euo pipefail
HERE="$(cd "$(dirname "$0")/.." && pwd)"
WEB=/var/www/lumio

echo "==> Installing nginx"
apt-get update -y && apt-get install -y nginx

echo "==> Copying website to $WEB"
mkdir -p "$WEB"
rm -rf "${WEB:?}"/*
cp -r "$HERE/site/." "$WEB/"
chown -R www-data:www-data "$WEB"
find "$WEB" -type d -exec chmod 755 {} \; ; find "$WEB" -type f -exec chmod 644 {} \;

echo "==> Configuring nginx"
cp "$HERE/deploy/nginx-lumio.conf" /etc/nginx/sites-available/lumio
ln -sf /etc/nginx/sites-available/lumio /etc/nginx/sites-enabled/lumio
rm -f /etc/nginx/sites-enabled/default
nginx -t
systemctl enable nginx
systemctl restart nginx

if command -v ufw >/dev/null 2>&1; then ufw allow 'Nginx Full' || true; ufw allow OpenSSH || true; fi

IP=$(curl -s -H Metadata:true "http://169.254.169.254/metadata/instance/network/interface/0/ipv4/ipAddress/0/publicIpAddress?api-version=2021-02-01&format=text" || true)
echo "==> Done. Open http://${IP:-<your-VM-public-IP>}/"
echo "    Remember: allow inbound port 80 (and 443) in the Azure Network Security Group."
