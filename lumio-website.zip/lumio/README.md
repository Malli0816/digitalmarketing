# Lumio Digital: website + Azure VM deploy

1. Create an Ubuntu VM in Azure. In Networking, open inbound ports 22, 80 and 443.
2. Upload this folder from your PC:  `scp -r lumio-website.zip azureuser@<VM-IP>:~`
3. On the VM:
   ```
   sudo apt-get install -y unzip && unzip lumio-website.zip && cd lumio
   sudo ./deploy/deploy.sh
   ```
4. Visit `http://<VM-IP>/`.  Pages: `/`, `/about`, `/services`, `/contact`.
5. HTTPS (after pointing your domain to the VM): `sudo apt install certbot python3-certbot-nginx && sudo certbot --nginx -d yourdomain.com`

To update later: edit files in `site/`, then run `sudo ./deploy/deploy.sh` again.
