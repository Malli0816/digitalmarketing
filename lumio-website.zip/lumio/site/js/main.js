(function(){
 var $=function(s,c){return Array.prototype.slice.call((c||document).querySelectorAll(s))};
 var bar=document.getElementById('progress'),hd=document.querySelector('header');
 function onScroll(){var h=document.documentElement,max=h.scrollHeight-h.clientHeight;
  bar.style.width=(max>0?h.scrollTop/max*100:0)+'%';hd.classList.toggle('small',h.scrollTop>30);
  $('[data-speed]').forEach(function(e){e.style.transform='translateY('+(h.scrollTop*e.dataset.speed)+'px)'})}
 addEventListener('scroll',onScroll,{passive:true});onScroll();
 // scroll reveal (replays on scroll up and down)
 var io=new IntersectionObserver(function(es){es.forEach(function(e){e.target.classList.toggle('in',e.isIntersecting)})},{threshold:.15});
 $('.rv').forEach(function(e,i){e.style.transitionDelay=(i%4)*90+'ms';io.observe(e)});
 // counters
 var co=new IntersectionObserver(function(es){es.forEach(function(e){if(!e.isIntersecting)return;
  var t=+e.target.dataset.n,s=0,el=e.target;(function step(){s+=Math.ceil(t/50);if(s>=t)s=t;el.textContent=s+(el.dataset.s||'');if(s<t)requestAnimationFrame(step)})();co.unobserve(el)})},{threshold:.6});
 $('[data-n]').forEach(function(e){co.observe(e)});
 // cursor glow + hero parallax
 var g=document.getElementById('glow');
 addEventListener('mousemove',function(e){g.style.left=e.clientX+'px';g.style.top=e.clientY+'px';
  var x=e.clientX/innerWidth-.5,y=e.clientY/innerHeight-.5;
  $('[data-depth]').forEach(function(el){var d=+el.dataset.depth;el.style.translate=(x*d)+'px '+(y*d)+'px'})});
 // 3D tilt cards
 $('.card').forEach(function(c){
  c.addEventListener('mousemove',function(e){var r=c.getBoundingClientRect();
   var x=(e.clientX-r.left)/r.width-.5,y=(e.clientY-r.top)/r.height-.5;
   c.style.transform='perspective(700px) rotateY('+x*12+'deg) rotateX('+-y*12+'deg) translateY(-6px)'});
  c.addEventListener('mouseleave',function(){c.style.transform=''})});
 // mobile menu
 var b=document.querySelector('.burger'),u=document.querySelector('nav ul');
 b.addEventListener('click',function(){var o=u.classList.toggle('open');b.setAttribute('aria-expanded',o)});
 // contact form (demo: shows confirmation; connect to your mail/API later)
 var f=document.getElementById('cf');
 if(f)f.addEventListener('submit',function(e){e.preventDefault();f.style.display='none';document.getElementById('ok').style.display='block'});
})();
